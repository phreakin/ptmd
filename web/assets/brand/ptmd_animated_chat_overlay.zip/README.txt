PTMD Animated Chat Overlay

Open index.html in a browser.

Files:
- index.html
- styles.css
- app.js

Use cases:
- screen record it for video
- import into OBS as a browser source
- use as reference for a live web overlay
