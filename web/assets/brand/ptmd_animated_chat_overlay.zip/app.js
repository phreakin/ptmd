const feed = document.getElementById('chat-feed');

const messages = [
    { user: 'MALL SIREQ', text: 'NOW', type: 'alert', color: '#ff4d5a' },
    { user: 'EMAL EEEAM', text: 'THEY WERE RIGHT!!', type: 'highlight', color: '#8BC34A' },
    { user: 'OHAEL EIEAL', text: 'NO WAY THIS CAN BE REAL...', type: 'alert', color: '#ff4d5a' },
    { user: 'YETI QM', text: 'CALLING IT NOW THEY LIED', type: 'data', color: '#B14CFF' },
    { user: 'SUMETHMAL91', text: 'IT ALL MAKES SENSE', type: 'data', color: '#3B82F6' },
    { user: 'SUINETRML01', text: "WE'RE NOT GETTING THE WHOLE STORY", type: 'data', color: '#3B82F6' },
    { user: 'SOMETBNMLOI', text: 'WE NEED TO KNOW MORE', type: 'data', color: '#3B82F6' },
    { user: 'YETI QM', text: 'WOW!', type: 'data', color: '#B14CFF' },
    { user: 'SUINETRMY', text: "THAT'S CRAZY!", type: 'data', color: '#3B82F6' },
    { user: 'YTAAL EEAAL', text: 'CALL THE LAWYERS', type: 'highlight', color: '#8BC34A' },
    { user: 'SOMETENFI', text: 'CALL COPS', type: 'data', color: '#3B82F6' },
    { user: 'YEII QM', text: "SOMETHING DOESN'T ADD UP!", type: 'alert', color: '#ff4d5a' }
];

const iconColors = {
    alert: '#ff4d5a',
    highlight: '#FFD60A',
    data: '#4db7ff'
};

function addMessage(m, delay = 0) {
    setTimeout(() => {
        const row = document.createElement('div');
        row.className = `msg ${m.type}`;
        row.innerHTML = `
            <div class="icon" style="background:${iconColors[m.type]}"></div>
            <div class="body">
                <div class="meta" style="color:${m.color}">${m.user}</div>
                <div class="text">${m.text}</div>
            </div>
        `;
        feed.appendChild(row);
        feed.scrollTop = feed.scrollHeight;

        const items = [...feed.querySelectorAll('.msg')];
        if (items.length > 10) {
            items[0].style.transition = 'all 220ms ease';
            items[0].style.opacity = '0';
            items[0].style.transform = 'translateX(-20px)';
            setTimeout(() => items[0]?.remove(), 220);
        }
    }, delay);
}

messages.forEach((m, i) => addMessage(m, i * 220));

setInterval(() => {
    const m = messages[Math.floor(Math.random() * messages.length)];
    addMessage(m, 0);
}, 1800);

const scan = document.createElement('div');
scan.className = 'scanline';
document.querySelector('.chat-overlay').appendChild(scan);
